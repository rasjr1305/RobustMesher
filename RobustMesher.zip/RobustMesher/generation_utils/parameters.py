from os import path
from warnings import warn
from .validation import validate_parameter


def cells_per_wavelength(method, degree, dimension):
    """Retrieve the number of cells per wavelength for a given method configuration.

    Parameters
    ----------
    method : str
        The finite element method to use. Options include:
        'mass_lumped_triangle' or 'spectral_quadrilateral'.
    degree : int
        The polynomial degree of the finite element basis functions.
        Valid values are 2, 3, 4, 5, 6, or 8 depending on the method.
    dimension : int
        The spatial dimension of the problem (2 or 3).

    Returns
    -------
    float or None
        The number of cells per wavelength for the specified configuration.
        Returns None if the configuration is not defined in the dictionary.

    Notes
    -----
    The returned value represents the minimum number of mesh cells required
    per wavelength to maintain numerical accuracy for the specified method
    and degree combination.

    Examples
    --------
    >>> cells_per_wavelength('mass_lumped_triangle', 2, 2)
    7.02
    >>> cells_per_wavelength('mass_lumped_triangle', 3, 3)
    3.72
    """
    cell_per_wavelength_dictionary = {
        'mass_lumped_triangle2dim2': 7.02,
        'mass_lumped_triangle3dim2': 3.70,
        'mass_lumped_triangle4dim2': 2.67,
        'mass_lumped_triangle5dim2': 2.03,
        'mass_lumped_triangle2dim3': 6.12,
        'mass_lumped_triangle3dim3': 3.72,
        'spectral_quadrilateral2dim2': None,
        'spectral_quadrilateral4dim2': None,
        'spectral_quadrilateral6dim2': None,
        'spectral_quadrilateral8dim2': None,
        'spectral_quadrilateral2dim3': None,
        'spectral_quadrilateral4dim3': None,
        'spectral_quadrilateral6dim3': None,
        'spectral_quadrilateral8dim3': None,
    }

    key = f"{method}{degree}dim{dimension}"

    return cell_per_wavelength_dictionary.get(key)


class MeshingParameters():  # noqa: UP039

    """Manage mesh parameters and configuration for seismic wave simulations.

    This class handles all aspects of mesh configuration including mesh type
    selection, dimensional parameters, boundary conditions, and automatic mesh
    generation based on velocity models and source frequencies.

    Attributes
    ----------
    input_mesh_dictionary : dict
        Dictionary containing initial mesh parameters.
    dimension : int
        Spatial dimension of the mesh (2 or 3).
    comm : MPI communicator
        MPI communicator for parallel computations.
    quadrilateral : bool
        Whether to use quadrilateral (True) or triangular (False) elements.
    mesh_type : str
        Type of mesh generation method. Options: 'firedrake_mesh',
        'user_mesh', 'file', 'robust_mesher', or 'gmsh_mesh'.
    method : str
        Finite element method. Options: 'mass_lumped_triangle',
        'DG_triangle', 'spectral_quadrilateral', 'DG_quadrilateral', or 'CG'.
    periodic : bool
        Whether the mesh has periodic boundary conditions.
    mesh_file : str
        Path to mesh file (.msh format).
    length_z : float
        Mesh length in the z-direction.
    length_x : float
        Mesh length in the x-direction.
    length_y : float
        Mesh length in the y-direction (for 3D meshes).
    user_mesh : object
        User-provided mesh object.
    output_filename : str
        Output filename for generated mesh (.msh format).
    source_frequency : float
        Source frequency in Hz for wavelength calculations.
    abc_pad_length : float
        Length of absorbing boundary condition padding layer.
    degree : int
        Polynomial degree of finite element basis functions.
    minimum_velocity : float
        Minimum velocity in the model for mesh size calculations.
    velocity_model : object
        Velocity model object for mesh adaptation.
    automatic_mesh : bool
        Whether mesh is automatically generated.
    edge_length : float
        Target edge length for mesh elements.
    cells_per_wavelength : float
        Number of cells per wavelength for mesh sizing.
    grid_velocity_data : dict
        Dictionary containing gridded velocity data with 'vp_values'
        and 'grid_spacing' keys.
    gradient_mask : object
        Mask for gradient calculations in inversions.
    negative_z : bool
        Whether z-axis points is always negative (True) or is positive (False).
    padding_type : str
        Type of domain padding for gmsh meshing. Options: 'rectangular', 'hyperelliptical', None.
    padding_x : float
        Size of padding in the x-direction.
    padding_z : float
        Size of padding in the z-direction.
    hyper_n : float
        Hyperellipse exponent for hyperelliptical padding.
    hmin_segy : float
        Minimum Element size for SEGY interpolation.
    grade : float
        Savitzky-Golay smoothing window fraction for each model axis;
        0 or None disables smoothing, and positive values must not exceed 1.
    water_interface : bool
        If True, detects and implements the water interface curve.
    water_search_value : float
        Value of the water speed that the water interface generator will use to find the bathymetry
    vp_water : float
        Substitute Water speed value if vs = 0.0.
    structured_mesh : bool
        If True, uses a structured quadrilateral mesh.
    unstructured_quad_mesh : bool
        If True, uses a 2D unstructured full-quadrilateral Gmsh mesh.
    min_element_size : float
        Element size constraint for structured mesh spacing.
    winslow_implementation : str
        Winslow smoothing version to use. Options: 'default', 'fast', 'numba'.
    apply_winslow : bool
        Whether to apply Winslow smoothing to the generated mesh.
    winslow_iterations : int
        Number of iterations for Winslow Smoothing.
    winslow_omega : float
        Winslow Smoothing node movement factor.
    extend_segy : bool
        Whether to extend the SEGY function sizing into the padding region.
    h_padding : float
        Constant padding element size used if extend_segy is False.
    gmsh_num_threads : int
        Number of threads used by parallel 3-D Gmsh/HXT meshing. Default is 1.

    Notes
    -----
    The class enforces mutual exclusivity between 'edge_length' and
    'cells_per_wavelength' parameters. Setting one will clear the other.

    Mesh dimensions (length_x, length_y, length_z, abc_pad_length, padding_x, padding_z) are
    checked for unit consistency (meters vs kilometers) and must all use
    the same unit system.
    """

    def __init__(self, input_mesh_dictionary=None, dimension=None, source_frequency=None, comm=None, quadrilateral=False, method=None, degree=None, velocity_model=None, abc_pad_length=None, negative_z=True):
        """Initialize the MeshingParameters class.

        Parameters
        ----------
        input_mesh_dictionary : dict, optional
            Dictionary containing initial mesh parameters. Can include keys
            such as 'mesh_type', 'mesh_file', 'length_x', 'length_y',
            'length_z', 'user_mesh', and 'output_filename'. Default is None.
        dimension : int, optional
            Spatial dimension of the mesh (2 or 3). Default is None.
        source_frequency : float, optional
            Source frequency in Hz for wavelength-based mesh sizing.
            Should be in range [1.5, 50] for realistic FWI cases.
            Default is None.
        comm : MPI communicator, optional
            MPI communicator for parallel mesh operations. Default is None.
        quadrilateral : bool, optional
            If True, uses quadrilateral or hexahedral elements; if False,
            uses triangular or tetrahedral elements. Default is False.
        method : str, optional
            Finite element method. Options: 'mass_lumped_triangle',
            'DG_triangle', 'spectral_quadrilateral', 'DG_quadrilateral',
            or 'CG'. Default is None.
        degree : int, optional
            Polynomial degree of finite element basis functions.
            Default is None.
        velocity_model : object, optional
            Velocity model object for mesh adaptation. Default is None.
        abc_pad_length : float, optional
            Length of absorbing boundary condition padding layer.
            Default is None.
        negative_z : bool, optional
            If True, z-axis points downward; if False, z-axis points upward.
            Default is True.
        """

        self.input_mesh_dictionary = input_mesh_dictionary or {}
        self.dimension = dimension
        self.comm = comm

        # Initialize private attributes for properties
        self._edge_length = None
        self._cells_per_wavelength = None
        self._method = None
        self._mesh_file = None
        self._mesh_type = None
        self._source_frequency = None
        self._abc_pad_length = None
        self._length_z = None
        self._length_x = None
        self._length_y = None
        self._user_mesh = None
        self._periodic = False
        self._unit = None
        self._output_filename = "automatic_mesh.msh"
        self._grid_velocity_data = None
        self._edge_length_z = None
        self._edge_length_x = None
        self._edge_length_y = None

        # Initialize private attributes for gmsh mesh properties
        self._padding_x = None
        self._padding_y = None
        self._padding_z = None
        self._h_padding = None
        self._padding_type = None
        self._winslow_implementation = None
        self._apply_winslow = None

        # Set basic attributes
        self.quadrilateral = quadrilateral
        self.method = method
        self.minimum_velocity = None
        self.gradient_mask = None
        self.negative_z = negative_z
        if velocity_model is None:
            self.velocity_model = self.input_mesh_dictionary.get("velocity_model", None)

        self.minimum_velocity = self.input_mesh_dictionary.get("minimum_velocity", None)

        # Apply parameters from input_mesh_dictionary and direct arguments
        self.source_frequency = self.input_mesh_dictionary.get("source_frequency", source_frequency)
        self.abc_pad_length = self.input_mesh_dictionary.get("abc_pad_length", abc_pad_length)
        self.degree = self.input_mesh_dictionary.get("degree", degree)
        self.mesh_type = self.input_mesh_dictionary.get("mesh_type")
        self.mesh_file = self.input_mesh_dictionary.get("mesh_file")
        self.length_z = self.input_mesh_dictionary.get("length_z")
        self.length_x = self.input_mesh_dictionary.get("length_x")
        self.length_y = self.input_mesh_dictionary.get("length_y")
        self.user_mesh = self.input_mesh_dictionary.get("user_mesh")
        self.dimension = self.input_mesh_dictionary.get("dimension", self.dimension)
        self.output_filename = self.input_mesh_dictionary.get("output_filename", "automatic_mesh.msh")
        self.cells_per_wavelength = self.input_mesh_dictionary.get("cells_per_wavelength")
        self.edge_length = self.input_mesh_dictionary.get("edge_length")
        self.edge_length_z = self.input_mesh_dictionary.get("edge_length_z")
        self.edge_length_x = self.input_mesh_dictionary.get("edge_length_x")
        self.edge_length_y = self.input_mesh_dictionary.get("edge_length_y")
        self.gradient_mask = self.input_mesh_dictionary.get("gradient_mask")

        # Apply gmsh meshing properties
        self.padding_type = self.input_mesh_dictionary.get("padding_type")
        self.padding_x = self.input_mesh_dictionary.get("padding_x")
        self.padding_y = self.input_mesh_dictionary.get("padding_y")
        self.padding_z = self.input_mesh_dictionary.get("padding_z")

        # Gmsh only parameters
        if self.mesh_type == "gmsh_mesh":
            self.winslow_implementation = self.input_mesh_dictionary.get("winslow_implementation", "numba")
            self.h_padding = self.input_mesh_dictionary.get("h_padding", 500.0)
            self.vp_water = self.input_mesh_dictionary.get("vp_water", None)
            self.structured_mesh = self.input_mesh_dictionary.get("structured_mesh", False)
            self.unstructured_quad_mesh = self.input_mesh_dictionary.get("unstructured_quad_mesh", False)
            self.hyper_n = self.input_mesh_dictionary.get("hyper_n", 3.0)
            self.hmin_segy = self.input_mesh_dictionary.get("hmin_segy", 0.0)
            self.grade = self.input_mesh_dictionary.get("grade", 0.9)
            self.water_interface = self.input_mesh_dictionary.get("water_interface", False)
            self.water_search_value = self.input_mesh_dictionary.get("water_search_value", 0.0)
            self.min_element_size = self.input_mesh_dictionary.get("min_element_size", 35.0)
            self.winslow_iterations = self.input_mesh_dictionary.get("winslow_iterations", 5000)
            self.winslow_omega = self.input_mesh_dictionary.get("winslow_omega", 0.5)
            self.extend_segy = self.input_mesh_dictionary.get("extend_segy", True)
            self.apply_winslow = self.input_mesh_dictionary.get("apply_winslow", True)
            self.segy_velocity_model = self.input_mesh_dictionary.get("segy_velocity_model", None)

            # 3d Meshing parameters
            self.segy_nz = self.input_mesh_dictionary.get("segy_nz", None)
            self.segy_nx = self.input_mesh_dictionary.get("segy_nx", None)
            self.segy_ny = self.input_mesh_dictionary.get("segy_ny", None)
            self.segy_dz = self.input_mesh_dictionary.get("segy_dz", None)
            self.segy_dx = self.input_mesh_dictionary.get("segy_dx", None)
            self.segy_dy = self.input_mesh_dictionary.get("segy_dy", None)
            self.segy_byte_order = self.input_mesh_dictionary.get("segy_byte_order", "big")
            self.segy_axes_order = self.input_mesh_dictionary.get("segy_axes_order", (0, 1, 2))
            self.segy_axes_order_sort = self.input_mesh_dictionary.get("segy_axes_order_sort", "F")
            self.segy_dtype = self.input_mesh_dictionary.get("segy_dtype", "float32")
            self.gmsh_parallel = self.input_mesh_dictionary.get("gmsh_parallel", False)
            self.gmsh_num_threads = self.input_mesh_dictionary.get("gmsh_num_threads", 1)

            if self.structured_mesh and self.unstructured_quad_mesh:
                raise ValueError(
                    "'structured_mesh' and 'unstructured_quad_mesh' are mutually exclusive."
                )
            if self.unstructured_quad_mesh and self.dimension == 3:
                raise ValueError(
                    "'unstructured_quad_mesh' is currently supported only for 2D Gmsh meshes."
                )

        self.automatic_mesh = self.mesh_type in {"firedrake_mesh", "robust_mesher", "gmsh_mesh"}
        self.is_complete = None
        self.check_completeness()

    def check_completeness(self, verbose=True):
        """Check if mesh parameters are complete for mesh generation.

        Sets the `is_complete` attribute to True if all required parameters
        are present for the configured mesh type, False otherwise.

        For automatic meshes (firedrake_mesh, robust_mesher, gmsh_mesh):
            - Requires either edge_length or cells_per_wavelength
            - If using cells_per_wavelength, also requires source_frequency
              and either minimum_velocity or grid velocity data

        For file-based meshes:
            - Requires mesh_file to be set

        For user-provided meshes:
            - Requires user_mesh to be set

        Notes
        -----
        The is_complete flag indicates readiness for mesh generation.
        It is considered complete when all required parameters for
        its mesh_type are present.

        verbose : bool
            If True, prints out the parameter that is missing.
        """
        if self.mesh_type is None:
            if verbose:
                print("Mesh incomplete: 'mesh_type' is not set.")
            self.is_complete = False
            return

        if self.automatic_mesh:
            # For automatic meshes, need either edge_length or cells_per_wavelength
            has_directional_size = (
                self.edge_length_z is not None
                or self.edge_length_x is not None
                or self.edge_length_y is not None
            )
            has_size_param = (
                self.edge_length is not None
                or has_directional_size
                or self.cells_per_wavelength is not None
            )
            if not has_size_param:
                if verbose:
                    print(f"Mesh incomplete: '{self.mesh_type}' requires either 'edge_length' or 'cells_per_wavelength'.")
                self.is_complete = False
                return

            # If using cells_per_wavelength, need frequency and some form of velocity definition
            if self.cells_per_wavelength is not None:
                if self.source_frequency is None:
                    if verbose:
                        print("Mesh incomplete: 'cells_per_wavelength' requires 'source_frequency'.")
                    self.is_complete = False
                    return

                has_velocity = (
                    self.minimum_velocity is not None
                    or self.grid_velocity_data is not None
                    or self.velocity_model is not None  # Accepts a string path for SEGY
                )

                if not has_velocity:
                    if verbose:
                        print("Mesh incomplete: 'cells_per_wavelength' requires 'minimum_velocity', 'grid_velocity_data', or 'velocity_model'.")
                    self.is_complete = False
                    return

            self.is_complete = True

        elif self.mesh_type == "file":
            # For file-based meshes, need mesh_file
            if self.mesh_file is None:
                if verbose:
                    print("Mesh incomplete: 'mesh_type' is 'file' but 'mesh_file' is not set.")
                self.is_complete = False
            else:
                self.is_complete = True

        elif self.mesh_type == "user_mesh":
            # For user-provided meshes, need user_mesh object
            if self.user_mesh is None:
                if verbose:
                    print("Mesh incomplete: 'mesh_type' is 'user_mesh' but 'user_mesh' object is not set.")
                self.is_complete = False
            else:
                self.is_complete = True

        else:
            if verbose:
                print("Mesh incomplete: Unknown mesh_type '{self.mesh_type}'.")
            self.is_complete = False

    def _set_length_with_unit_check(self, attr_name, value):
        """Set a length attribute with automatic unit consistency checking.

        Parameters
        ----------
        attr_name : str
            Name of the attribute to set (e.g., '_length_x', '_length_z').
        value : float or None
            The length value to set. Values > 100 are assumed to be in meters,
            values <= 100 are assumed to be in kilometers.

        Raises
        ------
        ValueError
            If the value is negative or if the inferred unit is inconsistent
            with previously set dimensions.

        Warnings
        --------
        Issues a warning if the inferred unit (meters or km) appears to be
        inconsistent with the unit of previously set dimension attributes.

        Notes
        -----
        This method helps ensure all spatial dimensions use consistent units.
        The unit is inferred from the magnitude: values > 100 are assumed to
        be in meters, while values <= 100 are assumed to be in kilometers.
        """

        if value is not None:
            if value > 100:
                new_unit = "meters"
            else:
                new_unit = "km"
        else:
            new_unit = None
        if not hasattr(self, "_unit") or self._unit is None:
            self._unit = new_unit
        elif new_unit != self._unit and value is not None:
            warn(
                f"{attr_name} value ({value}) appears to be "
                f"in {new_unit}, but the current unit is "
                f"{self._unit}. Please check for consistency."
            )
        if value is not None and value < 0.0:
            raise ValueError(
                f"Please do not use negative value for {attr_name}")
        setattr(self, attr_name, value)

    @property
    def grid_velocity_data(self):
        """Get the gridded velocity data.

        Returns
        -------
        dict or None
            Dictionary containing 'vp_values' and 'grid_spacing' keys,
            or None if not set.
        """
        return self._grid_velocity_data

    @grid_velocity_data.setter
    def grid_velocity_data(self, value):
        """Set attribute of the velocity data.

        Parameters
        ----------
        value : dict or None
            Dictionary containing gridded velocity information.
            Must include 'vp_values' and 'grid_spacing' keys.

        Raises
        ------
        ValueError
            If value is not None and does not contain required keys for either
            a scalar or directional grid spacing description.
        """
        if value is not None:
            if "vp_values" not in value:
                raise ValueError("Grid velocity data needs vp_values key.")
            has_scalar_spacing = "grid_spacing" in value
            has_directional_spacing = all(
                key in value for key in ("grid_spacing_z", "grid_spacing_x")
            )
            if value.get("length_y") not in (None, 0.0):
                has_directional_spacing = has_directional_spacing and (
                    "grid_spacing_y" in value
                )
            if not has_scalar_spacing and not has_directional_spacing:
                raise ValueError(
                    "Grid velocity data needs either grid_spacing or directional grid_spacing_z/grid_spacing_x keys."
                )
        self._grid_velocity_data = value

    @property
    def output_filename(self):
        """Get the output filename for mesh generation.

        Returns
        -------
        str or None
            The output filename with .msh extension, or None if not set.
        """
        return self._output_filename

    @output_filename.setter
    def output_filename(self, value):
        """Set the output filename for mesh generation.

        Parameters
        ----------
        value : str or None
            Output filename. Must end with .msh extension.

        Raises
        ------
        ValueError
            If value does not end with .msh extension (except .vtk which
            issues a warning).

        Warnings
        --------
        Issues a warning if .vtk extension is used, as VTK meshes are for
        visualization only and cannot be used for simulation.
        """
        if value is not None:
            if isinstance(value, str) and value.endswith('.vtk'):
                warn("VTK meshes for visualization only, will not run a simulation.")
            elif not (isinstance(value, str) and value.endswith('.msh')):
                raise ValueError(f"mesh_file '{value}' must be a .msh file")
        self._output_filename = value

    @property
    def edge_length(self):
        """Get the target edge length for mesh elements.

        Returns
        -------
        float or None
            The target edge length for mesh elements, or None if not set.
        """
        return self._edge_length

    @edge_length.setter
    def edge_length(self, value):
        """Set the target edge length for mesh elements.

        Parameters
        ----------
        value : float or None
            The target edge length for mesh elements.

        Warnings
        --------
        Setting edge_length will clear any previously set cells_per_wavelength
        value, as these parameters are mutually exclusive.

        Notes
        -----
        Only one of edge_length or cells_per_wavelength can be set at a time.
        Setting this property will automatically set cells_per_wavelength to None.
        """
        if value is not None and self.cells_per_wavelength is not None:
            warn(
                "Mutual exclusion: Both 'edge_length' and "
                "'cells_per_wavelength' control mesh size, "
                "but only one can be set at a time. Setting "
                "'edge_length' will override and remove the "
                "previously set 'cells_per_wavelength'. If "
                "you wish to use 'cells_per_wavelength' instead, "
                "set it after setting 'edge_length'."
            )
            self._cells_per_wavelength = None

        self._edge_length = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    def _resolved_edge_length(self, axis):
        axis_value = getattr(self, f"edge_length_{axis}", None)
        if axis_value is not None:
            return axis_value
        return self.edge_length

    @property
    def edge_length_z(self):
        return self._edge_length_z

    @edge_length_z.setter
    def edge_length_z(self, value):
        self._edge_length_z = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def edge_length_x(self):
        return self._edge_length_x

    @edge_length_x.setter
    def edge_length_x(self, value):
        self._edge_length_x = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def edge_length_y(self):
        return self._edge_length_y

    @edge_length_y.setter
    def edge_length_y(self, value):
        self._edge_length_y = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def cells_per_wavelength(self):
        """Get the number of cells per wavelength for mesh sizing.

        Returns
        -------
        float or None
            The number of cells per wavelength, or None if not set.
        """
        return self._cells_per_wavelength

    @cells_per_wavelength.setter
    def cells_per_wavelength(self, value):
        """Set the number of cells per wavelength for mesh sizing.

        Parameters
        ----------
        value : float or None
            The desired number of cells per wavelength.

        Warnings
        --------
        Setting cells_per_wavelength will clear any previously set edge_length
        value, as these parameters are mutually exclusive.

        Notes
        -----
        Only one of cells_per_wavelength or edge_length can be set at a time.
        Setting this property will automatically set edge_length to None.
        """
        if value is not None and self.edge_length is not None:
            warn("Setting cells_per_wavelength "
                 "removes edge_length parameter")
            self._edge_length = None

        self._cells_per_wavelength = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def method(self):
        """Get the finite element method.

        Returns
        -------
        str or None
            The finite element method name, or None if not set.
        """
        return self._method

    @method.setter
    def method(self, value):
        """Set the finite element method.

        Parameters
        ----------
        value : str or None
            The finite element method to use. Must be one of:
            'mass_lumped_triangle', 'DG_triangle', 'spectral_quadrilateral',
            'DG_quadrilateral', or 'CG'.

        Raises
        ------
        ValueError
            If value is not None and not one of the allowed method types.
        """
        allowed_types = [
            "mass_lumped_triangle",
            "DG_triangle",
            "spectral_quadrilateral",
            "DG_quadrilateral",
            "CG",
            None,
        ]

        self._method = validate_parameter("method", value, allowed_types)

    @property
    def mesh_file(self):
        """Get the path to the mesh file.

        Returns
        -------
        str or None
            The path to the mesh file, or None if not set.
        """
        return self._mesh_file

    @mesh_file.setter
    def mesh_file(self, value):
        """Set the path to the mesh file.

        Parameters
        ----------
        value : str or None
            Path to the mesh file. Must end with .msh extension and exist
            in the filesystem.

        Raises
        ------
        ValueError
            If value does not end with .msh extension.
        FileNotFoundError
            If the specified file does not exist.
        """
        if value is not None:
            if not (isinstance(value, str) and value.endswith('.msh')):
                raise ValueError(f"mesh_file '{value}' must be a .msh file")
            if not path.exists(value):
                raise FileNotFoundError(f"mesh_file '{value}' does not exist")
        self._mesh_file = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def mesh_type(self):
        """Get the mesh generation type.

        Returns
        -------
        str or None
            The mesh generation type, or None if not set.
        """
        return self._mesh_type

    @mesh_type.setter
    def mesh_type(self, value):
        """Set the mesh generation type.

        Parameters
        ----------
        value : str or None
            The mesh generation type. Must be one of: 'firedrake_mesh',
            'user_mesh', 'file', 'robust_mesher', or 'gmsh_mesh'.

        Raises
        ------
        ValueError
            If value is not one of the allowed mesh types.
        """
        allowed_types = ["firedrake_mesh", "user_mesh", "file", "robust_mesher", "gmsh_mesh"]
        if value is not None and value not in allowed_types:
            validate_parameter("mesh_type", value, allowed_types)

        self._mesh_type = value

        if value in ["firedrake_mesh", "robust_mesher"]:
            self.automatic_mesh = True

        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def source_frequency(self):
        """Get the source frequency.

        Returns
        -------
        float or None
            The source frequency in Hz, or None if not set.
        """
        return self._source_frequency

    @source_frequency.setter
    def source_frequency(self, value):
        """Set the source frequency for wavelength calculations.

        Parameters
        ----------
        value : float, int, or None
            The source frequency in Hz. Should be in range [1.5, 50]
            for realistic FWI applications.

        Raises
        ------
        TypeError
            If value is not None and not a number.

        Warnings
        --------
        Issues a warning if frequency < 1.5 Hz (too low for realistic FWI)
        or if frequency > 50 Hz (too high, should apply low-pass filter).
        """
        if value is None:
            self._source_frequency = value
        elif not isinstance(value, (int, float)):
            raise TypeError("Source frequency must be a number"
                            f", got {type(value).__name__}")
        else:
            if value < 1.5:
                warn(f"Source frequency of {value} "
                     "too low for realistic FWI case")
            elif value > 50:
                warn(f"Source frequency of {value} too high for "
                     "realistic FWI case, please low-pass filter")
            self._source_frequency = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def abc_pad_length(self):
        """Get the absorbing boundary condition padding length.

        Returns
        -------
        float or None
            The ABC padding length, or None if not set.
        """
        return self._abc_pad_length

    @abc_pad_length.setter
    def abc_pad_length(self, value):
        """Set the absorbing boundary condition padding length.

        Parameters
        ----------
        value : float or None
            The length of the ABC padding layer. Must be non-negative.

        Raises
        ------
        ValueError
            If value is negative or if the unit appears inconsistent with
            other dimension attributes.
        """
        self._set_length_with_unit_check("_abc_pad_length", value)

    @property
    def length_z(self):
        """Get the mesh extent in the z-direction.

        Returns
        -------
        float or None
            The mesh extent in the z-direction, or None if not set.
        """
        return self._length_z

    @length_z.setter
    def length_z(self, value):
        """Set the mesh extent in the z-direction.

        Parameters
        ----------
        value : float or None
            The mesh extent in the z-direction. Must be non-negative.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        self._set_length_with_unit_check("_length_z", value)

    @property
    def length_x(self):
        """Get the mesh extent in the x-direction.

        Returns
        -------
        float or None
            The mesh extent in the x-direction, or None if not set.
        """
        return self._length_x

    @length_x.setter
    def length_x(self, value):
        """Set the mesh extent in the x-direction.

        Parameters
        ----------
        value : float or None
            The mesh extent in the x-direction. Must be non-negative.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        self._set_length_with_unit_check("_length_x", value)

    @property
    def length_y(self):
        """Get the mesh extent in the y-direction.

        Returns
        -------
        float or None
            The mesh extent in the y-direction, or None if not set.
        """
        return self._length_y

    @length_y.setter
    def length_y(self, value):
        """Set the mesh extent in the y-direction (for 3D meshes).

        Parameters
        ----------
        value : float or None
            The mesh extent in the y-direction. Must be non-negative.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        self._set_length_with_unit_check("_length_y", value)

    @property
    def user_mesh(self):
        """Get the user-provided mesh object.

        Returns
        -------
        object or None
            The user-provided mesh object, or None if not set.
        """
        return self._user_mesh

    @user_mesh.setter
    def user_mesh(self, value):
        """Set a user-provided mesh object.

        Parameters
        ----------
        value : object or None
            A user-provided mesh object.

        Notes
        -----
        Setting a user mesh automatically changes mesh_type to 'user_mesh'.
        """
        if value is not None:
            self.mesh_type = "user_mesh"
        self._user_mesh = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def periodic(self):
        """Periodic boundary condition flag.

        Returns
        -------
        bool
            True if periodic boundary conditions are enabled, False otherwise.
        """
        return self._periodic

    @periodic.setter
    def periodic(self, value):
        """Set the periodic boundary condition flag.

        Parameters
        ----------
        value : bool
            If True, enable periodic boundary conditions.

        Raises
        ------
        ValueError
            If value is True but mesh_type is not 'firedrake_mesh',
            as periodic meshes are only supported with Firedrake meshes.
        """
        if self.mesh_type != "firedrake_mesh" and value is True:
            raise ValueError("Periodic meshes are only supported "
                             "with Firedrake meshes for now.")
        self._periodic = value

    @property
    def padding_x(self):
        """Pad length in the x-direction.

        float or None
            The padding length in the x-direction, or None if not set.
            If None and abc_pad_length is set it returns it.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        if self._padding_x is None:
            return self._abc_pad_length
        return self._padding_x

    @padding_x.setter
    def padding_x(self, value):
        self._set_length_with_unit_check("_padding_x", value)

    @property
    def padding_y(self):
        """Pad length in the y-direction.

        Returns
        -------
        float or None
            The y-direction padding. If it is not set, the
            absorbing-boundary padding length is returned.
        """
        if self._padding_y is None:
            return self._abc_pad_length
        return self._padding_y

    @padding_y.setter
    def padding_y(self, value):
        self._set_length_with_unit_check("_padding_y", value)

    @property
    def padding_z(self):
        """Pad length in the z-direction.

        float or None
            The padding length in the z-direction, or None if not set.
            If None and abc_pad_length is set it returns it.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        if self._padding_z is None:
            return self._abc_pad_length
        return self._padding_z

    @padding_z.setter
    def padding_z(self, value):
        self._set_length_with_unit_check("_padding_z", value)

    @property
    def h_padding(self):
        """Constant padding element size.

        float or None
            The padding element size, or None if not set.

        Raises
        ------
        ValueError
            If value is negative or if the inferred unit appears inconsistent
            with other dimension attributes.
        """
        return self._h_padding

    @h_padding.setter
    def h_padding(self, value):
        self._set_length_with_unit_check("_h_padding", value)

    @property
    def padding_type(self):
        """Type of padding applied to the gmsh mesh.

        str or None
            The padding type ('rectangular', 'hyperelliptical', or None).
        """
        return self._padding_type

    @padding_type.setter
    def padding_type(self, value):
        allowed_types = [None, "rectangular", "hyperelliptical"]
        if value not in allowed_types:
            validate_parameter("padding_type", value, allowed_types)
        self._padding_type = value

    @property
    def winslow_implementation(self):
        """The implementation method used for Winslow smoothing.

        str or None
            The implementation method ('default', 'fast', 'numba', or None).

        Raises
        ------
        ValueError
            If value is not None and not one of the allowed implementations.
        """
        return self._winslow_implementation

    @winslow_implementation.setter
    def winslow_implementation(self, value):
        allowed_types = ["default", "fast", "numba"]
        if value is not None and value not in allowed_types:
            validate_parameter("winslow_implementation", value, allowed_types)
        self._winslow_implementation = value

    @property
    def apply_winslow(self):
        """Flag indicating whether to apply Winslow smoothing.

        bool
            True if Winslow smoothing is enabled, False otherwise.
        """
        return self._apply_winslow

    @apply_winslow.setter
    def apply_winslow(self, value):
        if value is not None and not isinstance(value, bool):
            raise TypeError(f"apply_winslow must be a boolean, got {type(value).__name__}")

        self._apply_winslow = value

    def set_mesh(
        self,
        user_mesh=None,
        input_mesh_parameters=None,
        abc_pad_length=None,
    ):
        """Update mesh parameters after initialization.

        This method updates mesh parameters by applying user-provided values,
        useful for modifying settings after the object has been created.

        Parameters
        ----------
        user_mesh : spyro.Mesh, optional
            A user-provided mesh object. Default is None.
        input_mesh_parameters : dict, optional
            Dictionary of mesh parameters to update. Can include any attribute
            of the MeshingParameters class. Default is None.
        abc_pad_length : float, optional
            Length of absorbing boundary condition padding layer.
            Overrides the value from input_mesh_parameters if provided.
            Default is None.

        Examples
        --------
        >>> mp = MeshingParameters(dimension=2, use_defaults=False)
        >>> mp.set_mesh(input_mesh_parameters={'mesh_type': 'firedrake_mesh',
        ...                                     'length_x': 10.0,
        ...                                     'length_z': 5.0})
        """
        if input_mesh_parameters is None:
            input_mesh_parameters = {}

        if abc_pad_length is not None:
            self.abc_pad_length = abc_pad_length

        if user_mesh is not None:
            self.user_mesh = user_mesh

        # Apply all provided parameters
        for key, value in input_mesh_parameters.items():
            if value is not None and hasattr(self, key):
                setattr(self, key, value)

        # Update automatic_mesh flag based on final mesh_type
        self.automatic_mesh = self.mesh_type in {"firedrake_mesh", "robust_mesher", "gmsh_mesh"}

    @property
    def velocity_model(self):
        return self._velocity_model

    @velocity_model.setter
    def velocity_model(self, value):
        self._velocity_model = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()

    @property
    def segy_velocity_model(self):
        return self._segy_velocity_model

    @segy_velocity_model.setter
    def segy_velocity_model(self, value):
        warn("Passing SEGY directly to the mesher is deprecated. Please use grid point velocity inputs.")
        self._segy_velocity_model = value
        if value is not None:
            self.velocity_model = value
        if hasattr(self, 'is_complete'):
            self.check_completeness()
